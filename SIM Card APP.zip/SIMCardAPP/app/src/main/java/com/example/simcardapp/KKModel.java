package com.example.simcardapp;

public class KKModel {
    private int id;
    private String name;

    public KKModel(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
