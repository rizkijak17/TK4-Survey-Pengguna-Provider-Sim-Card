package com.example.simcardapp;

import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPagerAdapter extends FragmentStateAdapter {

    public ViewPagerAdapter(MainActivity activity) {
        super(activity);
    }

    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new GoogleMapsFragment(); // Tab 1: Google Maps
            case 1:
                return new KKDataFragment(); // Tab 2: Data KK
            case 2:
                return new AccountFragment(); // Tab 3: Account
            default:
                throw new IllegalArgumentException("Invalid position: " + position);
        }
    }

    @Override
    public int getItemCount() {
        return 3; // Ada 3 tab
    }
}