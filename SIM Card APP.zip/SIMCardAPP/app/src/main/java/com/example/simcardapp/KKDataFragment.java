package com.example.simcardapp;

import android.database.Cursor;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class KKDataFragment extends Fragment {

    private RecyclerView recyclerView;
    private KKAdapter kkAdapter;
    private DatabaseHelper dbHelper;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_data_kk, container, false);

        // Inisialisasi SwipeRefreshLayout
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setOnRefreshListener(() -> {
            loadKKData(); // Memuat ulang data saat pengguna melakukan swipe refresh
            swipeRefreshLayout.setRefreshing(false); // Menghentikan animasi refresh
        });

        // Inisialisasi RecyclerView
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Inisialisasi DatabaseHelper
        dbHelper = new DatabaseHelper(getContext());

        // Memuat data KK saat pertama kali fragment dibuat
        loadKKData();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Memuat ulang data setiap kali fragment menjadi terlihat
        loadKKData();
    }

    private void loadKKData() {
        Cursor cursor = dbHelper.getAllKK();
        List<KKModel> kkList = new ArrayList<>();
        while (cursor.moveToNext()) {
            int kkIdIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_KK_ID);
            int kkNameIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_KK_NAME);

            if (kkIdIndex != -1 && kkNameIndex != -1) {
                kkList.add(new KKModel(
                        cursor.getInt(kkIdIndex),
                        cursor.getString(kkNameIndex)
                ));
            }
        }
        cursor.close();

        if (kkAdapter == null) {
            kkAdapter = new KKAdapter(kkList, getContext());
            recyclerView.setAdapter(kkAdapter);
        } else {
            kkAdapter.updateData(kkList);
        }
    }
}